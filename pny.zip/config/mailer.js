module.exports = {
  MAILGUN_USER: 'raghukamc@gmail.com',
  MAILGUN_PASS: 'p@55raghucs2techw0rd'
};